import * as CryptoJS from 'crypto-js';

export class encryptionDataUtil {

    static readonly key = 'PBEWithMD5AndDES';
    static readonly iv = CryptoJS.enc.Hex.parse('00000000000000000000000000000000');

    static encryptData(data: string): string {
        return CryptoJS.AES.encrypt(data, CryptoJS.enc.Utf8.parse(this.key), { iv: this.iv }).toString();
    }

    
  // key = 'PBEWithMD5AndDES';
  // iv = CryptoJS.enc.Hex.parse('00000000000000000000000000000000');

  // testLogin() {
  //   const data = 'Pass@123456000';
  //   const encryptedData = this.encryptData(data, this.key, this.iv);
  //   console.log(encryptedData);
  // }


  // encryptData(data: string, key: string, iv: any): string {
  //   const encryptedData = CryptoJS.AES.encrypt(data, CryptoJS.enc.Utf8.parse(key), { iv: iv }).toString();
  //   return encryptedData;
  // }
}