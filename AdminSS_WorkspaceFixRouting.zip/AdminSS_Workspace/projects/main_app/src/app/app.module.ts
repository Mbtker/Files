import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import {MatTreeModule} from '@angular/material/tree';
import {MatIconModule} from '@angular/material/icon';
import { HomeComponent } from './components/app/home/home.component';
import { FooterComponent } from './components/app/layout/footer/footer.component';
import { HeaderComponent } from './components/app/layout/header/header.component';
import { LayoutComponent } from './components/app/layout/layout.component';
import { SideMenuComponent } from './components/app/layout/side-menu/side-menu.component';
import { MainMenuComponent } from './components/userAccessAndAuthorization/main-menu/main-menu.component';
import { UserGroupsComponent } from './components/userAccessAndAuthorization/user-groups/user-groups.component';

export function HttpLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http, './assets/i18n/messages_', '.json');
}

@NgModule({
  declarations: [
    AppComponent,
    LayoutComponent,
    HomeComponent,
    SideMenuComponent,
    FooterComponent,
    HeaderComponent,
    MainMenuComponent,
    UserGroupsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    MatTreeModule,
    MatIconModule,
    TranslateModule.forRoot({
      defaultLanguage : 'en',
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient],
      },
    })
  ],
  providers: [
    provideAnimationsAsync()
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
