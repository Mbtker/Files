import { Component } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-layout',
  templateUrl: './layout.component.html',
  styleUrl: './layout.component.css'
})
export class LayoutComponent {

  dir = 'ltr';

  constructor(translateService: TranslateService) { 
    let lang = translateService.getDefaultLang();
    this.dir = lang === "ar" ? "rtl" : "ltr";
  }

}
