import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { SharedService } from '../../../../../shared/services/SharedService';
import { userDTO } from '../../../dto/userDTO';
import { FormsModule } from '@angular/forms';
import { encryptionDataUtil } from '../../../../../shared/util/encryptionDataUtil';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule, TranslateModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})

export class LoginComponent {

  loginDTO: userDTO = new userDTO;
  
  constructor(private MyService: SharedService, private translateService: TranslateService, private router: Router) { }

  onChangeLang() {
    let lang = this.translateService.getDefaultLang();
   
    if (lang == 'ar') {
      this.translateService.setDefaultLang('en');
      this.translateService.use('en');
      this.dir = "ltr";
      this.langString = 'عربي';
      document.querySelector('html')?.setAttribute('lang', 'en');
    } else {
      this.translateService.setDefaultLang('ar');
      this.translateService.use('ar');
      this.dir = "rtl";
      this.langString = 'En';
      document.querySelector('html')?.setAttribute('lang', 'ar');
    }
  }
  langString = 'عربي';
  dir =  this.translateService.getDefaultLang() === "ar" ? "rtl" : "ltr";

  onLogin() {
    // this.router.navigateByUrl('/home');

   // this.loginDTO.password = encryptionDataUtil.encryptData(this.loginDTO.password);
    this.MyService.login(this.loginDTO).subscribe((res:any) => {
      console.log(this.loginDTO);
      console.log(res);
      if(res['errId'] == '-3') {
        this.translateService.get('ADNotAuthenticated').subscribe((res: string) => {
          alert(res);
        })
      } else if(res['errId'] == '-2') {
        this.translateService.get('InactiveUser').subscribe((res: string) => {
          alert(res);
        })
      } else if(res['errId'] == '-1') {
        this.translateService.get('IncorrectLoginInfo').subscribe((res: string) => {
          alert(res);
        })
      } else {
        this.loginDTO = res;
        this.router.navigateByUrl('/home');
      }
    });
    
  }

}
