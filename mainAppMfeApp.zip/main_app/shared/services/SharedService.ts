
import { HttpClient, HttpClientModule, HttpHeaders } from '@angular/common/http';
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";

@Injectable({
    providedIn: 'root'
  })

export class SharedService {

     readonly APIUrl = 'http://10.39.20.67:8083/';

     readonly headers = new HttpHeaders()
     .set('content-type', 'application/json')
     .set('Access-Control-Allow-Origin', '*')
     .set('Access-Control-Allow-Methods', 'POST, GET, OPTIONS');

     constructor(private http: HttpClient) {}

    login(data:any):Observable<any[]> {
        return this.http.post<any>(this.APIUrl+'staffs/authenticate', data);
    }

}
