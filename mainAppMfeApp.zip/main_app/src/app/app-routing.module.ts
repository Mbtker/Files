import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './components/app/login/login.component';
import { LayoutComponent } from './components/app/layout/layout.component';
import { HomeComponent } from './components/app/home/home.component';
import { MainMenuComponent } from './components/userAccessAndAuthorization/main-menu/main-menu.component';
import { UserGroupsComponent } from './components/userAccessAndAuthorization/user-groups/user-groups.component';
import { loadRemoteModule } from '@angular-architects/module-federation';

const routes: Routes = [
  {
    path: '', 
    redirectTo:'login', 
    pathMatch: 'full'
  }, {
    path: 'login', 
    component: LoginComponent
  }, {
    path: '', 
    component: LayoutComponent,
    children: [ {
        path: 'home',
        component: HomeComponent
      } ]
  }, {
    path: '', 
    component: LayoutComponent,
    children: [ {
        path: 'userGroups',
        component: UserGroupsComponent
      } ]
  }, {
    path: '',
    component: LayoutComponent,
    children: [
      { path: 'mainMenu', component: MainMenuComponent }
    ]
  }, {
    path: 'new', 
    component: LayoutComponent,
    children: [ {
      path: '', 
      loadChildren: () => loadRemoteModule({
        type: 'module', remoteEntry: 'http://localhost:4100/remoteEntry.js',
        exposedModule: './DemoModule', 
       }).then((m) => m.AppModule),
      } ]
  }, {
    path: 'audit', 
    component: LayoutComponent,
    children: [ {
      path: '', 
      loadChildren: () => loadRemoteModule({
        type: 'module', remoteEntry: 'http://localhost:4100/remoteEntry.js',
        exposedModule: './DemoModule', 
       }).then((m) => m.AppModule),
      } ]
  } , {
    path: 'approve', 
    component: LayoutComponent,
    children: [ {
      path: 'approve', 
      loadChildren: () => loadRemoteModule({
        type: 'module', remoteEntry: 'http://localhost:4100/remoteEntry.js',
        exposedModule: './DemoModule', 
       }).then((m) => m.AppModule),
      } ]
  } , {
    path: 'tracking', 
    component: LayoutComponent,
    children: [ {
      path: 'tracking', 
      loadChildren: () => loadRemoteModule({
        type: 'module', remoteEntry: 'http://localhost:4100/remoteEntry.js',
        exposedModule: './DemoModule', 
       }).then((m) => m.AppModule),
      } ]
  }  


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
