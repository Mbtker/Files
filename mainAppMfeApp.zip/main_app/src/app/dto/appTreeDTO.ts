export class AppTreeModel {
    id: number;
    nodeEnDesc: string;
    nodeArDesc: string;
    navigationPage: string;
    parentNode: ParentNode;
    sequenceNo: string;
    categoryTypeId: number;
    amendBy: number;
    constructor() {
      this.id = 0;
      this.nodeEnDesc = '';
      this.nodeArDesc = '';
      this.navigationPage = '';
      this.parentNode = new ParentNode();
      this.sequenceNo = '';
      this.categoryTypeId = 0;
      this.amendBy = 0;
    }
  }
  
  export class ParentNode {
    id: number;
    nodeEnDesc: string;
    nodeArDesc: string;
    navigationPage: string;
    parentNode: ParentNode;
    sequenceNo: string;
    categoryTypeId: number;
    amendBy: number;
    constructor() {
      this.id = 0;
      this.nodeEnDesc = '';
      this.nodeArDesc = '';
      this.navigationPage = '';
      this.parentNode = new ParentNode();
      this.sequenceNo = '';
      this.categoryTypeId = 0;
      this.amendBy = 0;
    }
  }