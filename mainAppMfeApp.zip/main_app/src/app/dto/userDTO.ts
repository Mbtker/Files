export class userDTO {
    staffId: number;
    staffIdNo: any;
    password: string;
    appTreeMenuDTO: any;
    lang: number;
    errId: number;
    errMsg: string;
    constructor() {
      this.staffId = 0;
      this.staffIdNo = null;
      this.password = '';
      this.appTreeMenuDTO = null;
      this.lang = 0;
      this.errId = 0;
      this.errMsg = '';
    }
  }
