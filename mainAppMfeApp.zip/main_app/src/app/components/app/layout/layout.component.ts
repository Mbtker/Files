import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-layout',
  templateUrl: './layout.component.html',
  styleUrl: './layout.component.css'
})
export class LayoutComponent implements OnInit {

  dir = 'ltr';

  constructor(translateService: TranslateService, private router: Router) { 
    let lang = translateService.getDefaultLang();
    this.dir = lang === "ar" ? "rtl" : "ltr";
  }

  ngOnInit(): void {
    if (localStorage.getItem('staffIdNo') == undefined || localStorage.getItem('staffIdNo') == null || localStorage.getItem('staffIdNo') == '') {
      localStorage.clear();
      this.router.navigateByUrl('/');
    }
  }

}
