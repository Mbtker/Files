import { Component, OnInit } from '@angular/core';
import { AppTreeModel } from '../../../../dto/appTreeDTO';
import { HttpClient } from '@angular/common/http';
import { Observable, noop } from 'rxjs';
import { FlatTreeControl } from '@angular/cdk/tree';
import { MatTreeFlatDataSource, MatTreeFlattener } from '@angular/material/tree';
import { Router } from '@angular/router';
import { SharedService } from '../../../../../../shared/services/SharedService';
import { userDTO } from '../../../../dto/userDTO';

@Component({
  selector: 'app-side-menu',
  templateUrl: './side-menu.component.html',
  styleUrl: './side-menu.component.css'
})

export class SideMenuComponent implements OnInit {

  url: string = '../../../../assets/appTreeExa.json'
  data: any = [];
  loginDTO: userDTO = new userDTO;

  constructor(private MyService: SharedService, private http: HttpClient, private router: Router) {

  }
  
  ngOnInit(): void {
    // this.getJSON().subscribe((res) => {
    //   this.dateSource.data = res;
    // })
    this.reloadSideList();

  }

  
  reloadSideList() {
    let staffIdNo = localStorage.getItem('staffIdNo');
    this.loginDTO.staffIdNo = staffIdNo;
    this.loginDTO.password = '000';
    
    this.MyService.login(this.loginDTO).subscribe((res:any) => {
      this.loginDTO = res;
      this.dateSource.data = this.loginDTO.appTreeMenuDTO;
      console.log('appTreeMenuDTO');
      console.log(this.loginDTO.appTreeMenuDTO);
    })
  }
    // Start side menu

    private _transformer = (node: MenuNode, level: number) => {
      return {
        expandable: !!node.childTreeMenuDTOList && node.childTreeMenuDTOList.length > 0,
        id: node.id,
        name: node.nodeEnDesc,
        level: level,
      };
    };

    treeControl = new FlatTreeControl<ExampleFlatNode>(
      node => node.level,
      node => node.expandable
    );


    treeFlattener = new MatTreeFlattener(
      this._transformer,
      node => node.level,
      node => node.expandable,
      node => node.childTreeMenuDTOList
    );

    dateSource = new MatTreeFlatDataSource(
      this.treeControl, 
      this.treeFlattener
    );


    hasChild = (_: number, node: ExampleFlatNode) => node.expandable;

    onNodeClicked(node: any) {
     console.log(node.id)
     if (node.id == 83) {
      this.router.navigate(['/mainMenu']);
     } else  if (node.id == 84) {
      this.router.navigate(['/userGroups']);
     } 
    }

    // End side menu

    nodeClicked(node: any) {
      if (this.treeControl.isExpanded(node)) {
          let parent = null;
      
          let index = this.treeControl.dataNodes.findIndex((n) => n === node);
      
          for (let i = index; i >= 0; i--) {
            if (node.level > this.treeControl.dataNodes[i].level) {
              parent = this.treeControl.dataNodes[i];
              break;
            }
          }
      
          if(parent){
          this.treeControl.collapseDescendants(parent);
          this.treeControl.expand(parent);
        } else {
          this.treeControl.collapseAll()
        }
          this.treeControl.expand(node);
      }
    }




  public initParentsOnly(data: [AppTreeModel]) {
  let ParentsOnly = [];
    for(const i in data) {
      if (data[i].parentNode == null) {
        ParentsOnly.push(data[i]);
      }
    }
    return ParentsOnly;
  }

  public getJSON(): Observable<any> {
    return this.http.get(this.url);
  }

  public initAllNodes(res: [AppTreeModel]) {
    for(const i in res) {
      if (res[i].parentNode == null || res[i].parentNode.id == 0) {
         console.log(res[i]);
      }
    }
  }
}


interface MenuNode {
  id: number;
  nodeEnDesc: string;
  nodeArDesc: string;
  navigationPage: string;
  childTreeMenuDTOList?: MenuNode[];
  sequenceNo: string;
  categoryTypeId: number;
  amendBy: number;
}

interface ExampleFlatNode {
  id: number;
  expandable: boolean;
  name: string;
  level: number;
}


