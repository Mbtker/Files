const { shareAll, withModuleFederationPlugin } = require('@angular-architects/module-federation/webpack');

module.exports = withModuleFederationPlugin({

  name: 'mfe-app',

  exposes: {
    // './Component': './projects/mfe-app/src/app/app.component.ts',
    './DemoModule': './projects/mfe-app/src/app/app.module.ts',
    './DemoNewModule': './projects/mfe-app/src/app/new/new.module.ts',
    './DemoAuditModule': './projects/mfe-app/src/app/audit/audit.module.ts',
    './DemoApproveModule': './projects/mfe-app/src/app/approve/approve.module.ts',
    './DemoTrackingModule': './projects/mfe-app/src/app/tracking/tracking.module.ts',
  },

  shared: {
    ...shareAll({ singleton: true, strictVersion: true, requiredVersion: 'auto' }),
  },

});
