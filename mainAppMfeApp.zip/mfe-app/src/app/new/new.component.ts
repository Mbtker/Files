import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { DemoSharedService } from '../../services/demo.shared.service';

@Component({
  selector: 'app-new',
  templateUrl: './new.component.html',
  styleUrl: './new.component.css',
})

export class NewComponent  implements OnInit {

  isLoading = false;

  demoData: createDemoData;

  constructor(private MyService: DemoSharedService) {
    this.isLoading = false;
    this.demoData = new createDemoData();
  }
  ngOnInit(): void {
   
  }


onAdd() {
  
  if (this.demoData.title == '') {
    alert('Enter the title!');
    return;
  }

  this.demoData.createBy = 5522;
  
  this.MyService.create(this.demoData).subscribe((res:any) => {
    console.log(res);
    this.demoData = new createDemoData();
    alert('The request was created successfully');
    this.isLoading = true;
 });

}
}


export class createDemoData {
  id: number;
  reqNo : string;
  title : string;
  createBy : number;
  auditBy : number;
  approveBy  : number;
  status  : number;
    constructor() {
      this.id = 0;
      this.reqNo = '';
      this.title = '';
      this.createBy = 0;
      this.auditBy = 0;
      this.approveBy = 0;
      this.status = 0;
    }
  }
