
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";

@Injectable({
    providedIn: 'root'
  })

export class DemoSharedService {

    // http://localhost:8084/demoTables/2
    readonly APIUrl = 'http://localhost:8084/demoTables/';

     constructor(private http: HttpClient) {}

    create(data:any):Observable<any[]> {
        return this.http.post<any>(this.APIUrl+'create', data);
    }

    getTaudit():Observable<any[]> {
        return this.http.get<any>(this.APIUrl+'creatededRequets');
    }

    findById(Id:number):Observable<any[]> {
        return this.http.get<any>(this.APIUrl+Id);
    }

    audit(data:any):Observable<any[]> {
        return this.http.post<any>(this.APIUrl+'audit', data);
    }

    getApprove():Observable<any[]> {
        return this.http.get<any>(this.APIUrl+'auditedRequets');
    }

    approve(data:any):Observable<any[]> {
        return this.http.post<any>(this.APIUrl+'approve', data);
    }

    getTrackingRequets():Observable<any[]> {
        return this.http.get<any>(this.APIUrl+'trackingRequets');
    }


}
