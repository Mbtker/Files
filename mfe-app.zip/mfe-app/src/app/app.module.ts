import { NgModule } from '@angular/core';
import { BrowserModule, provideClientHydration } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { NewComponent } from './new/new.component';
import { AuditComponent } from './audit/audit.component';
import { ApproveComponent } from './approve/approve.component';
import { TrackingComponent } from './tracking/tracking.component';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { RouterModule, RouterOutlet, Routes } from '@angular/router';
import { TabsComponent } from './tabs/tabs.component';

const routes: Routes =  [
  { path: "", redirectTo: "new", pathMatch: "full" },
  // { path: "Tabs", component: TabsComponent }, 
  {
    path: 'new', 
    component: TabsComponent,
    children: [ {
      path: '',
      component: NewComponent
      } ]
  }, {
    path: 'audit', 
    component: TabsComponent,
    children: [ {
      path: '',
      component: AuditComponent
      } ]
  }, {
    path: 'approve', 
    component: TabsComponent,
    children: [ {
      path: '',
      component: ApproveComponent
      } ]
  }, {
    path: 'tracking', 
    component: TabsComponent,
    children: [ {
      path: '',
      component: TrackingComponent
      } ]
  }
];

@NgModule({
  declarations: [
    AppComponent,
    NewComponent,
    AuditComponent,
    ApproveComponent,
    TrackingComponent,
    TabsComponent
  ],
  imports: [
    CommonModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule, 
    MatIconModule,
    RouterOutlet,
    RouterModule.forChild(routes),
  ],
  exports: [RouterModule],
  providers: [
    provideClientHydration()
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
