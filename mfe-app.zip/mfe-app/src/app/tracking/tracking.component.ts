import { Component, OnInit } from '@angular/core';
import { DemoData } from '../../dto/demo.data.dto';
import { DemoSharedService } from '../../services/demo.shared.service';

@Component({
  selector: 'app-tracking',
  templateUrl: './tracking.component.html',
  styleUrl: './tracking.component.css'
})
export class TrackingComponent  implements OnInit {

  isLoading = false;
  ListArray = [];

  constructor(private MyService: DemoSharedService) {
   }

  ngOnInit(): void {
    this.isLoading = true;
     this.onGetList();
  }

  onGetList() {
    console.log('getTrackingRequets');
    this.MyService.getTrackingRequets().subscribe((data:any) => {
      console.log(data);
      this.ListArray = data;
      this.isLoading = false;
    });
  } 

  
onSelectRow(cell: DemoData) {


}


}
