import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { DemoSharedService } from '../../services/demo.shared.service';
import { DemoData } from '../../dto/demo.data.dto';
import { createDemoData } from '../new/new.component';

@Component({
  selector: 'app-audit',
  templateUrl: './audit.component.html',
  styleUrl: './audit.component.css'
})
export class AuditComponent implements OnInit {

  isLoading = false;
  ListArray = [];

  constructor(private MyService: DemoSharedService) {
   }

  ngOnInit(): void {
    this.isLoading = true;
     this.onGetList();
  }

  onGetList() {
    this.MyService.getTaudit().subscribe((data:any) => {
      console.log(data);
      this.ListArray = data;
      this.isLoading = false;
    });
  } 

  
onSelectRow(cell: DemoData) {
this.MyService.findById(cell.id).subscribe((data:any) => {
  let demoData = new createDemoData();
  demoData = data;
  demoData.auditBy = 9931;
  this.MyService.audit(demoData).subscribe((data:any) => {
    alert('Sent successfully');
    this.isLoading = true;
    this.onGetList();
  });
});


}
  
}

