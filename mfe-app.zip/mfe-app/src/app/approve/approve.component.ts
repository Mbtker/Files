import { Component, OnInit } from '@angular/core';
import { DemoData } from '../../dto/demo.data.dto';
import { DemoSharedService } from '../../services/demo.shared.service';
import { createDemoData } from '../new/new.component';

@Component({
  selector: 'app-approve',
  templateUrl: './approve.component.html',
  styleUrl: './approve.component.css'
})
export class ApproveComponent  implements OnInit {

  isLoading = false;
  ListArray = [];

  constructor(private MyService: DemoSharedService) {
   }

  ngOnInit(): void {    
    this.isLoading = true;
     this.onGetList();
  }

  onGetList() {
    this.MyService.getApprove().subscribe((data:any) => {
      console.log(data);
      this.ListArray = data;
      this.isLoading = false;
    });
  } 


onSelectRow(cell: DemoData) {
  this.MyService.findById(cell.id).subscribe((data:any) => {
    let demoData = new createDemoData();
    demoData = data;
    demoData.approveBy = 5522;
    this.MyService.approve(demoData).subscribe((data:any) => {
      alert('Approved successfully');
      this.isLoading = true;
      this.onGetList();
    });
  });
}

}
