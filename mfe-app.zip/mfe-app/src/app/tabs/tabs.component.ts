import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-tabs',
  templateUrl: './tabs.component.html',
  styleUrl: './tabs.component.css'
})
export class TabsComponent implements OnInit {

  @Input() tabsArray: string[] = ['New','Audit','Approve','Tracking'];
  @Output() onTabChange = new EventEmitter<number>();
  activatedTab: number = 1;
  element: any;

  constructor(private router: Router) { }

  ngOnInit(): void {
    this.activatedTab = 1;
    
    console.log('===> From mfe-app');
    console.log(localStorage.getItem('staffIdNo'));

    this.element = document.getElementById("myDIV1");
    this.element.classList.remove("active");
    this.element = document.getElementById("myDIV2");
    this.element.classList.remove("active");
    this.element = document.getElementById("myDIV3");
    this.element.classList.remove("active");
    this.element = document.getElementById("myDIV4");
    this.element.classList.remove("active");

    if (this.router.url.includes('new')) {
      this.element = document.getElementById("myDIV1");
      this.element.classList.add("active");
    } else if (this.router.url.includes('audit')) {
      this.element = document.getElementById("myDIV2");
      this.element.classList.add("active");
    } else if (this.router.url.includes('approve')) {
      this.element = document.getElementById("myDIV3");
      this.element.classList.add("active");
    } else if (this.router.url.includes('tracking')) {
      this.element = document.getElementById("myDIV4");
      this.element.classList.add("active");
    }

  }

  setTab(index:number) { 
    // this.element = document.getElementById("myDIV1");
    // this.element.classList.remove("active");
    // this.element = document.getElementById("myDIV2");
    // this.element.classList.remove("active");
    // this.element = document.getElementById("myDIV3");
    // this.element.classList.remove("active");
    // this.element = document.getElementById("myDIV4");
    // this.element.classList.remove("active");
    // this.element = document.getElementById("myDIV" + index);
    // this.element.classList.add("active");
    this.activatedTab = index;
    debugger;
    this.onTabChange.emit(this.activatedTab);
    
    if (index == 1) { // New 
      this.router.navigate([`/new`]);
    } else if (index == 2) { // Audit
      this.router.navigate([`/audit`]);
    } else if (index == 3) { // Approve
      this.router.navigate([`/approve`]);
    } else if (index == 4) { // Tracking
      this.router.navigate([`/tracking`]);
    } 
  }
}