export class DemoData {
  id: number;
  reqNo : string;
  title : string;
  createByName : string;
  auditByName : string;
  approveName  : string;
  statusEnDesc  : string;
    constructor() {
      this.id = 0;
      this.reqNo = '';
      this.title = '';
      this.createByName = '';
      this.auditByName = '';
      this.approveName = '';
      this.statusEnDesc = '';
    }
  }