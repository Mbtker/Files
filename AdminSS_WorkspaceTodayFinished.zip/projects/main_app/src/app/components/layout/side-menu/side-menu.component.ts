import { Component, OnInit } from '@angular/core';
import * as appTreeJson from '../../../../assets/appTreeExample.json';
import { AppTreeModel } from '../../../models/appTreeModel';
import { HttpClient } from '@angular/common/http';
import { Observable, noop } from 'rxjs';
import { FlatTreeControl } from '@angular/cdk/tree';
import { MatTreeFlatDataSource, MatTreeFlattener } from '@angular/material/tree';

@Component({
  selector: 'app-side-menu',
  templateUrl: './side-menu.component.html',
  styleUrl: './side-menu.component.css'
})

export class SideMenuComponent {

  url: string = '../../../../assets/appTreeExample.json'
  data: any = [];
  

    // Start side menu

    private _transformer = (node: MenuNode, level: number) => {
      return {
        expandable: !!node.children && node.children.length > 0,
        id: node.id,
        name: node.nodeEnDesc,
        level: level,
      };
    };

    treeControl = new FlatTreeControl<ExampleFlatNode>(
      node => node.level,
      node => node.expandable
    );


    treeFlattener = new MatTreeFlattener(
      this._transformer,
      node => node.level,
      node => node.expandable,
      node => node.children
    );

    dateSource = new MatTreeFlatDataSource(
      this.treeControl, 
      this.treeFlattener
    );

    hasChild = (_: number, node: ExampleFlatNode) => node.expandable;

    onNodeClicked(node: any) {
     console.log(node.id)
    }

    // End side menu




  constructor(private http: HttpClient) {
    this.getJSON().subscribe((res) => {
      this.preperingData(res);
    })

  }

  public preperingData(data: [AppTreeModel]) {

    let ParentsOnly = this.initParentsOnly(data);

    for(const i in ParentsOnly) {

      var ParentModal = new MyModel();
      ParentModal.id = ParentsOnly[i].id;
      ParentModal.nodeEnDesc = ParentsOnly[i].nodeEnDesc;
      ParentModal.nodeArDesc = ParentsOnly[i].nodeArDesc;
      ParentModal.navigationPage = ParentsOnly[i].navigationPage;
      ParentModal.sequenceNo = ParentsOnly[i].sequenceNo;
      ParentModal.categoryTypeId = ParentsOnly[i].categoryTypeId;
      ParentModal.amendBy = ParentsOnly[i].amendBy;

     // console.log('Parent: ' + ParentsOnly[i].nodeEnDesc)
      for(const x in data) {
        if (data[x].parentNode != null && data[x].parentNode.id == ParentsOnly[i].id) {
       //   console.log('Child: ' + data[x].nodeEnDesc)
          var  ChildrenModal = new MyModel();
          ChildrenModal.id = data[x].id;
          ChildrenModal.nodeEnDesc = data[x].nodeEnDesc;
          ChildrenModal.nodeArDesc = data[x].nodeArDesc;
          ChildrenModal.navigationPage = data[x].navigationPage;
          ChildrenModal.sequenceNo = data[x].sequenceNo;
          ChildrenModal.categoryTypeId = data[x].categoryTypeId;
          ChildrenModal.amendBy = data[x].amendBy;
          ChildrenModal.children = [];
          ParentModal.children?.push(data[x]);
        } 
      }
      this.data.push(ParentModal);
    }
    this.dateSource.data = this.data;
  }

  public initParentsOnly(data: [AppTreeModel]) {
  let ParentsOnly = [];
    for(const i in data) {
      if (data[i].parentNode == null) {
        ParentsOnly.push(data[i]);
      }
    }
    return ParentsOnly;
  }

  public getJSON(): Observable<any> {
    return this.http.get(this.url);
  }

  public initAllNodes(res: [AppTreeModel]) {
    for(const i in res) {
      if (res[i].parentNode == null || res[i].parentNode.id == 0) {
         console.log(res[i]);
      }
    }

    // for(const i in this.rootNodes) {
    //   console.log(this.rootNodes[i]);
    // }
  }

  // for (ApplicationTree node : mainNodes) {
  //   // TreeNode t1 = createTree(node, root);
  //   if (node.getParentNodeId() == null || nodesMap.get(node.getParentNodeId().getId()) == null)
  //     treeNode = createTreeDocument(node, rootForAllTree);
  //   else
  //     treeNode = createTreeDocument(node,nodesMap.get(node.getParentNodeId().getId()));
  //   nodesMap.put(node.getId(), treeNode);
  // }

}

// Start side menu

// interface MenuNode {
//   id: number,
//   name: string;
//   children?: MenuNode[];
// }

interface MenuNode {
  id: number;
  nodeEnDesc: string;
  nodeArDesc: string;
  navigationPage: string;
  children?: MenuNode[];
  sequenceNo: string;
  categoryTypeId: number;
  amendBy: number;
}

interface ExampleFlatNode {
  id: number;
  expandable: boolean;
  name: string;
  level: number;
}

export class MyModel {
  id: number;
  nodeEnDesc: string;
  nodeArDesc: string;
  navigationPage: string;
  children?: MyModel[];
  sequenceNo: string;
  categoryTypeId: number;
  amendBy: number;
  constructor() {
    this.id = 0;
    this.nodeEnDesc = '';
    this.nodeArDesc = '';
    this.navigationPage = '';
    this.children = [];
    this.sequenceNo = '';
    this.categoryTypeId = 0;
    this.amendBy = 0;
  }
}

// const TREE_DATA: MenuNode[] = [
//   {
//     id: 1,
//     name: 'Fruit',
//     children: [ { id: 2,name: 'Apple' }, { id: 3,name: 'Banana' }, { id: 4,name: 'Fruit loops' }, ]
//   }, 
//   {
//     id: 5,
//     name: 'Vegetables',
//     children: [
//       { 
//         id: 6,
//         name: 'Green',
//         children: [{ id: 7, name: 'Broccoli' }, { id: 8, name: 'Brusseles sprouts' }] 
//       },
//       { 
//         id: 9,
//         name: 'Orange',
//         children: [{ id: 10, name: 'Pumpkins' }, { id: 11, name: 'Carrots' }] 
//       },
//     ]
//   }
// ]

// End side menu