import { Component, OnInit } from '@angular/core';
import * as appTreeJson from '../../../../assets/appTreeExample.json';
import { AppTreeModel } from '../../../models/appTreeModel';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-side-menu',
  templateUrl: './side-menu.component.html',
  styleUrl: './side-menu.component.css'
})
export class SideMenuComponent {

  url: string = '../../../../assets/appTreeExample.json'
  data = [];
  rootNodes = [];

  constructor(private http: HttpClient) {

    this.getJSON().subscribe((res) => {
      this.initAllNodes(res);
    })

  }

  public getJSON(): Observable<any> {
    return this.http.get(this.url);
  }

  public initAllNodes(res: [AppTreeModel]) {
    for(const i in res) {
      if (res[i].parentNode == null || res[i].parentNode.id == 0) {
         console.log(res[i]);
      }
    }



    
    // for(const i in this.rootNodes) {
    //   console.log(this.rootNodes[i]);
    // }
  }





  // for (ApplicationTree node : mainNodes) {
  //   // TreeNode t1 = createTree(node, root);
  //   if (node.getParentNodeId() == null || nodesMap.get(node.getParentNodeId().getId()) == null)
  //     treeNode = createTreeDocument(node, rootForAllTree);
  //   else
  //     treeNode = createTreeDocument(node,nodesMap.get(node.getParentNodeId().getId()));
  //   nodesMap.put(node.getId(), treeNode);
  // }

}
