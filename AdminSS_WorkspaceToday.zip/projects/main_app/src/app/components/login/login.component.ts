import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {

  constructor(private translateService: TranslateService, private router: Router) {}


  onChangeLang() {

    let lang = this.translateService.getDefaultLang();
    if (lang == 'ar') {
      this.translateService.setDefaultLang('en');
      this.translateService.use('en');
    } else {
      this.translateService.setDefaultLang('ar');
      this.translateService.use('ar');
    }
  }

  onLogin() {
    this.router.navigateByUrl('/home');
  }

}
