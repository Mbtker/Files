import { Component } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})

export class AppComponent {
  
  dir = 'auto';
  constructor(private translateService: TranslateService) { 
    this.translateService.onLangChange.subscribe(() => this.getCurrentLang()); 
  }

  getCurrentLang() {
    if (this.translateService.currentLang == 'ar') {
      this.dir = 'rtl';
    } else {
      this.dir = 'ltr';
    }
  }

}
