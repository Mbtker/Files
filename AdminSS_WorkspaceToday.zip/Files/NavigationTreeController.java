/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.psmmc.rp.watheeqmvn.controller;
import org.springframework.context.annotation.Scope;

import javax.inject.Inject;
import javax.inject.Named;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.el.ELContext;
import javax.el.ExpressionFactory;
import javax.el.ValueExpression;
import javax.faces.application.Application;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

import org.apache.log4j.Logger;
import org.primefaces.event.NodeCollapseEvent;
import org.primefaces.event.NodeExpandEvent;
import org.primefaces.event.NodeSelectEvent;
import org.primefaces.event.NodeUnselectEvent;
import org.primefaces.model.DefaultTreeNode;
import org.primefaces.model.TreeNode;
import org.psmmc.rp.watheeqmvn.controller.finance.accounting.AccountTreeControler;
import org.psmmc.rp.watheeqmvn.controller.user.UserAuthorizationBean;
import org.psmmc.rp.watheeqmvn.domains.ApplicationTree;
import org.psmmc.rp.watheeqmvn.domains.CostCode;
import org.psmmc.rp.watheeqmvn.domains.Document;
import org.psmmc.rp.watheeqmvn.domains.User;
import org.psmmc.rp.watheeqmvn.services.ApplicationTreeService;


/**
 *
 * @author MBadawy
 */
@Named("navigationTreeController")
@Scope("session")
public class NavigationTreeController implements Serializable {
    
    /**
	 * 
	 */
	private static final long serialVersionUID = -381530884891455928L;
	public final static String LANGUAGE_EN = "en";
    public final static String LANGUAGE_AR = "ar";
    private TreeNode rootForChildOnly;
    private TreeNode rootForAllTree;
    private List<ApplicationTree> childOnlyNavigationNodes;
    private List<String> userAuthorizedNavigationPages;
    //private List<ApplicationTree> rootNavigationNodes;
    private String currentLanguage;
    private boolean loadChildNodesOnly = false;
    private String documentType;
    private String searchWord;
    private TreeNode oldSelectedNode;
    private List<TreeNode> allTreeNodesForFullTree;
    private List<TreeNode> allTreeNodesForFullChildOnlyTree;
    private List<TreeNode> allTreeNodes;
    private TreeNode tNode;
    private List<TreeNode> listOfNodesContainsSearchString;
    private TreeNode parentNode;
    private List<TreeNode> allParentNoodes;
    private List<TreeNode> allParentNoodesIncludeNode;
    private boolean enableSearchButt;
    private int searchIndex = 0;
  //TODO Select Navigation Tree Node When Open Page From URL
    private String currentNavigationPage = "";
    /*private String currentNavigationPage = "#";*/
    private String oldNavigationPage = "mainPage.xhtml";
    private boolean isSearchByButtons;
    private List<ApplicationTree> footerATreeChildPages;
    private List<ApplicationTree> childNodes;
    private User currentUser;
    //private TreeNode oldSelectedTreeNode;
    
    
    
    @Inject
    private ApplicationTreeService applicationTreeService;
    
	protected static final Logger logger = Logger.getLogger(AccountTreeControler.class);
	
    public NavigationTreeController()  { 
    	
    }
    
    @PostConstruct
    public void init() {   
    	currentUser = getCurrentUser();
        //childOnlyNavigationNodes = applicationTreeService.getUserAuthorizedPages(currentUser);
        //rootNavigationNodes = applicationTreeService.getUserAuthorizedRootNodes(currentUser);
        initAllNodes();
        //initChildsOnly();
    }

    // next button action - Go to next tree node contains the search word
    public void goToNextSearchNode()  {
        if (listOfNodesContainsSearchString != null && searchIndex < listOfNodesContainsSearchString.size() - 1) {
            isSearchByButtons = true;
            searchIndex += 1;
            selectNodeByIndex();
        }
    }

    // Previuos button action - Go to previous tree node contains the search word
    public void goToPreviousSearchNode()  {
        if (searchIndex > 0) {
            isSearchByButtons = true;
            searchIndex -= 1;
            selectNodeByIndex();
        }
    }

    // decide if tree node is parent for other nodes or child 
    //(Child = Has navigation page opened when select the node )
   /* private boolean isChildTreeNode(TreeNode t)  {
        ApplicationTree appTreeNode;
        appTreeNode = applicationTreeService.findApplicationTreeByID( ((Document) t.getData()).getId());
        if (appTreeNode != null && appTreeNode.getNavigationPage() != null && appTreeNode.getNavigationPage().trim().length() > 0) {
            return true;
        } else {
            return false;
        }
    }*/

    //Enable next , previous search buttons if there is search word
    public void handleEnableDisableSearchButtons() {
        if (searchWord != null && searchWord.trim().length() > 0) {
            enableSearchButt = true;
        } else {
            enableSearchButt = false;
        }
    }

    // find tree node that contains the search word by index of search
    // ( index +1 , -1 when press next , previous search buttons ) 
    private void selectNodeByIndex()  {
        if (searchIndex >= 0 && searchIndex < listOfNodesContainsSearchString.size()) {
            tNode = listOfNodesContainsSearchString.get(searchIndex);
            if (tNode != null) {
                if (oldSelectedNode != null && oldSelectedNode != tNode) {
                	oldSelectedNode.setSelected(false);
                    allParentNoodes = new ArrayList<TreeNode>();
                    for (TreeNode parentNode : getAllParents(oldSelectedNode)) {
                        parentNode.setExpanded(false);
                    }
                    oldSelectedNode.setExpanded(false);
                }
                tNode.setSelected(true);
                allParentNoodes = new ArrayList<TreeNode>();
                for (TreeNode parentNode : getAllParents(tNode)) {
                    parentNode.setExpanded(true);
                }
                tNode.setExpanded(true);
                oldSelectedNode = tNode;
                OpenNavigationPage(tNode,false);
            }
        }
        isSearchByButtons = false;
    }

    // blur listener for the search word input text
    // search tree nodes description contains search word
    public void handleSearchTreeNodes()   {
        //setCurrentLanguage();   // set current language when changed from the combobox
        searchIndex = 0;
        //handleEnableDisableSearchButtons();
        if (searchWord != null && searchWord.trim().length() > 0) {
            if(!enableSearchButt)
                enableSearchButt = true;
            listOfNodesContainsSearchString = findTreeNodesContainsSearchString(); // get all tree nodes has the search string
            selectNodeByIndex();
        } else {
            if (oldSelectedNode != null) {
            	oldSelectedNode.setSelected(false);
                allParentNoodes = new ArrayList<TreeNode>();
                for (TreeNode parentNode : getAllParents(oldSelectedNode)) {
                    parentNode.setExpanded(false);
                }
                oldSelectedNode.setExpanded(false);
            }
        }
    }

    // get all tree nodes that contains the search word
    private List<TreeNode> findTreeNodesContainsSearchString() {
        allTreeNodes = new ArrayList<TreeNode>();
        listOfNodesContainsSearchString = new ArrayList<TreeNode>();
        Document document = null;
        for (TreeNode filterdNode : getAllChildren(isLoadChildNodesOnly()?rootForChildOnly:rootForAllTree)) {
        	document = (Document) filterdNode.getData();
            //String nodeDesc = (currentLanguage.equals(LANGUAGE_AR)) ? d.getArabicName() : (null == d.getEnglishName() || "".equals(d.getEnglishName())) ? d.getArabicName() : d.getEnglishName();
            if (document.getSearchableField().toLowerCase().contains(searchWord.trim().toLowerCase())) {
                listOfNodesContainsSearchString.add(filterdNode);
            }
        }
        return listOfNodesContainsSearchString;
    }

    // get all tree nodes
    private void getAllNodes() {
        allTreeNodes = new ArrayList<TreeNode>();
        allTreeNodesForFullTree = new ArrayList<TreeNode>();
        allTreeNodesForFullChildOnlyTree = new ArrayList<TreeNode>();
        if(rootForAllTree != null && allTreeNodesForFullTree != null && allTreeNodesForFullTree.size() == 0)
            allTreeNodesForFullTree = getAllChildren(rootForAllTree);
        if(rootForChildOnly != null && allTreeNodesForFullChildOnlyTree != null && allTreeNodesForFullChildOnlyTree.size() == 0){
            allTreeNodes = new ArrayList<TreeNode>();
            allTreeNodesForFullChildOnlyTree = getAllChildren(rootForChildOnly);
        }
    }

    /* when select child node close all expanded other nodes under other parents
     and expand this node and its parents nodes only */
    private void expandSelectedNodeOnly(TreeNode tNode) {
        getAllNodes();
        for (TreeNode t : allTreeNodesForFullTree) {
            t.setSelected(false);
            t.setExpanded(false);
        }
        for (TreeNode t : allTreeNodesForFullChildOnlyTree) {
            t.setSelected(false);
            t.setExpanded(false);
        }
        if (tNode != null) {
            tNode.setSelected(true);
            allParentNoodes = new ArrayList<TreeNode>();
            TreeNode fullViewTNode = null;
            TreeNode childViewTNode = null;
            if (isLoadChildNodesOnly()) { // affect nodes at child only tree view when make changes on full tree view selection
                for (TreeNode tempNode : allTreeNodesForFullTree) {
                    if (((Document) tempNode.getData()).getId().compareTo(((Document) tNode.getData()).getId()) == 0) {
                        fullViewTNode = tempNode;
                        fullViewTNode.setSelected(true);
                        break;
                    }
                }
            }
            else{ // affect nodes at full tree view when make changes on child only tree view selection
                for (TreeNode tempNode : allTreeNodesForFullChildOnlyTree) {
                    if (((Document) tempNode.getData()).getId().compareTo(((Document) tNode.getData()).getId()) == 0) {
                        childViewTNode = tempNode;
                        childViewTNode.setSelected(true);
                        break;
                    }
                }
            }
            for (TreeNode pNode : getAllParents((fullViewTNode == null) ? tNode : fullViewTNode)) {
                if (pNode != null) {
                    pNode.setExpanded(true);
                }
            }
            tNode.setExpanded(true);
            if(fullViewTNode != null)
                fullViewTNode.setExpanded(true);
        }
    }

    // get all child and non child tree nodes under specific node
    private List<TreeNode> getAllChildren(TreeNode node) {
    	List<TreeNode> nodeChildrens = node.getChildren();
        for (TreeNode child : nodeChildrens) {
            allTreeNodes.add(child);
            getAllChildren(child);
        }
        return allTreeNodes;
    }

    // get all parents of specific tree node
    private List<TreeNode> getAllParents(TreeNode node) {
        parentNode = node.getParent();
        allParentNoodes.add(parentNode);
         if (parentNode != null && parentNode.getParent() != null) {
            getAllParents(parentNode);
        }
        return allParentNoodes;
    }
    
 // get all parents of specific tree node with this tree node
    private List<TreeNode> getAllParentsIncludeTreeNode(TreeNode node) {
    	allParentNoodesIncludeNode.add(node);
        parentNode = node.getParent();
        allParentNoodesIncludeNode.add(parentNode);
         if (parentNode != null && parentNode.getParent() != null) {
        	 getAllParentsIncludeTreeNode(parentNode);
        }
        return allParentNoodesIncludeNode;
    }
    
    // action event for show childs nodes only button
    public void loadChildsNodesOnly() {
    	if (rootForChildOnly == null) {
            rootForChildOnly = new DefaultTreeNode("root", null);
    	}
        //searchIndex = 0;
        //searchWord = null;
        handleEnableDisableSearchButtons();
        loadChildNodesOnly = true;
        //initChildsOnly();
    }

    // action event for show all nodes ( chils and parent ) button
    public void loadAllNodes()  {
        //searchIndex = 0;
        //searchWord = null;
        handleEnableDisableSearchButtons();
        loadChildNodesOnly = false;
        //initAllNodes();
    }
    

	private void initAllNodes() {
		if (rootForAllTree == null) {
			childOnlyNavigationNodes = new ArrayList<ApplicationTree>();
			userAuthorizedNavigationPages = new ArrayList<String>();
			rootForAllTree = new DefaultTreeNode("root", null);
			Map<Long, TreeNode> nodesMap = new HashMap<Long, TreeNode>();
			applicationTreeService.clear();
			List<ApplicationTree> mainNodes = applicationTreeService.findUserTreeApplicationTreeNodes(currentUser.getId(), 533L);
			TreeNode treeNode = null;
			for (ApplicationTree node : mainNodes) {
				// TreeNode t1 = createTree(node, root);
				if (node.getParentNodeId() == null || nodesMap.get(node.getParentNodeId().getId()) == null)
					treeNode = createTreeDocument(node, rootForAllTree);
				else
					treeNode = createTreeDocument(node,nodesMap.get(node.getParentNodeId().getId()));
				nodesMap.put(node.getId(), treeNode);
			}

			// print only executable pages
			initChildsOnly();

		}
	}
    
    private void initChildsOnly(){
    	if (rootForChildOnly == null) {
            rootForChildOnly = new DefaultTreeNode("root", null);
            Collections.sort(childOnlyNavigationNodes,ApplicationTree.sequenceNoComparator);
            String documentType2;
            String nodeArabicDescription;
            String nodeEnglishDescription;
            for (ApplicationTree navNode1 : childOnlyNavigationNodes) {
                nodeArabicDescription = navNode1.getNodeArDesc();
                nodeEnglishDescription = (null == navNode1.getNodeEnDesc() || "".equals(navNode1.getNodeEnDesc())) ? navNode1.getNodeArDesc() : navNode1.getNodeEnDesc();
                documentType2 = "Pages Document";
                TreeNode node1 = new DefaultTreeNode("document", new Document(navNode1.getId(), nodeArabicDescription, nodeEnglishDescription, documentType2,navNode1), rootForChildOnly);
            }
		}
    }
       
        
        private TreeNode createTreeDocument(ApplicationTree navNode, TreeNode parentNode) {
    		TreeNode newNode;
    		String nodeArabicDescription = navNode.getNodeArDesc();
            String nodeEnglishDescription = (null == navNode.getNodeEnDesc() || "".equals(navNode.getNodeEnDesc())) ? navNode.getNodeArDesc() : navNode.getNodeEnDesc();
            documentType = (null == navNode.getNavigationPage() || "".equals(navNode.getNavigationPage())) ? "Folder" : "Pages Document";
    		
            
            if (applicationTreeService.isChildNavigationPage(navNode)) {
                newNode = new DefaultTreeNode("document", new Document(navNode.getId(), nodeArabicDescription, nodeEnglishDescription, documentType,navNode), parentNode);
                if(childOnlyNavigationNodes != null && !childOnlyNavigationNodes.contains(navNode)){
                	childOnlyNavigationNodes.add(navNode);
                	userAuthorizedNavigationPages.add(navNode.getNavigationPage());
                }
                	
            } else {
                newNode = new DefaultTreeNode(new Document(navNode.getId(), nodeArabicDescription, nodeEnglishDescription, documentType,navNode), parentNode);
            }
    		return newNode;
    	}
    

    public TreeNode getRoot() {
        return isLoadChildNodesOnly()?rootForChildOnly:rootForAllTree;
    }

    private boolean isChildOfParentNode(TreeNode childNode , TreeNode parentNode){
    	allTreeNodes = new ArrayList<TreeNode>();
    	allTreeNodes = getAllChildren(parentNode);
    	if(allTreeNodes != null && allTreeNodes.contains(childNode))
    		return true;
    	return false;
    }
    
  //private TreeNode oldExpandedTreeNode;
    // action event for select tree node
    public void onNodeSelect(NodeSelectEvent event)  {
        TreeNode treeNode = event.getTreeNode();       
        if (treeNode != null) {
            if(treeNode.isExpanded() && !treeNode.isLeaf())//&& ((Document)oldSelectedNode.getData()).getId() == ( ((Document)treeNode.getData()).getId() )){
                onTreeNodeUnSelect(treeNode,true);
            //}
            else{
                onTreeNodeSelect(treeNode);
            }               
        }
    }
   
    private void onTreeNodeSelect(TreeNode treeNode){
        if (treeNode.getChildCount() == 0) { //Select executable tree node (Navigation Page)
            OpenNavigationPage(treeNode, false);
        }
        else{ // Select tree folder node                   
            if (oldSelectedNode != null) {
                oldSelectedNode.setSelected(false);
                allParentNoodesIncludeNode = new ArrayList<TreeNode>();
                getAllParentsIncludeTreeNode(oldSelectedNode);
                for (TreeNode parentTNode : allParentNoodesIncludeNode) {
                    if (!isChildOfParentNode(treeNode,parentTNode))                           
                        parentTNode.setExpanded(false);
                }
            }               
            treeNode.setExpanded(true);
            treeNode.setSelected(true);   
            oldSelectedNode = treeNode;
        }
    }
   
    public void onNodeUnSelect(NodeUnselectEvent event) {
        TreeNode treeNode = event.getTreeNode();
        onTreeNodeUnSelect(treeNode,false);       
    }
   
    private void onTreeNodeUnSelect(TreeNode treeNode, boolean isSelected){
        if (treeNode != null) {
            if (treeNode.getChildCount() == 0) { //UnSelect executable tree node (Navigation Page)
                ;
            }
            else{ // UnSelect tree folder node               
                treeNode.setExpanded(false);
                treeNode.setSelected(isSelected);
                /*for (TreeNode tNode : treeNode.getChildren()) {
                    tNode.setExpanded(false);
                }*/               
            }
        }
    }
    
    
    /*//private TreeNode oldExpandedTreeNode;
    // action event for select tree node
    public void onNodeSelect(NodeSelectEvent event)  {
		TreeNode treeNode = event.getTreeNode();
		if (treeNode != null) {
			if (treeNode.getChildCount() == 0) { //Select executable tree node (Navigation Page)
				OpenNavigationPage(treeNode, false);
			}
			else{ // Select tree folder node					
				if (oldSelectedNode != null) {
					oldSelectedNode.setSelected(false);
					allParentNoodesIncludeNode = new ArrayList<TreeNode>();
					getAllParentsIncludeTreeNode(oldSelectedNode);
					for (TreeNode parentTNode : allParentNoodesIncludeNode) {
						if (!isChildOfParentNode(treeNode,parentTNode))							
							parentTNode.setExpanded(false);
					}
				}				
				treeNode.setExpanded(true);
				treeNode.setSelected(true);	
				oldSelectedNode = treeNode;
			}
		}
    }
    
    public void onNodeUnSelect(NodeUnselectEvent event) {
		TreeNode treeNode = event.getTreeNode();
		if (treeNode != null) {
			if (treeNode.getChildCount() == 0) { //UnSelect executable tree node (Navigation Page)
				;
			}
			else{ // UnSelect tree folder node				
				treeNode.setExpanded(false);
				treeNode.setSelected(false);
				for (TreeNode tNode : treeNode.getChildren()) {
					tNode.setExpanded(false);
				}				
			}
		}
	}*/
    
 /*   public void onNodeExpand(NodeExpandEvent event){
    	TreeNode treeNode = event.getTreeNode();
		if (treeNode != null) {				
				if (oldExpandedTreeNode != null) {
					//oldExpandedTreeNode.setSelected(false);
					allParentNoodesIncludeNode = new ArrayList<TreeNode>();
					getAllParentsIncludeTreeNode(oldExpandedTreeNode);
					for (TreeNode parentTNode : allParentNoodesIncludeNode) {
						if (!isChildOfParentNode(treeNode,parentTNode))							
							parentTNode.setExpanded(false);
					}
				}				
				treeNode.setExpanded(true);
				//treeNode.setSelected(true);	
				oldExpandedTreeNode = treeNode;
		}
    }   */
	
    
    public void onNodeCollapse(NodeCollapseEvent event){
        TreeNode tempNode = event.getTreeNode();
        if(tempNode != null){
            tempNode.setExpanded(false);
            tempNode.setSelected(false);
        }
    }
    
    /*public void onFastLinkSelect(String navigationPage){
        FacesContext
                        .getCurrentInstance()
                        .getApplication()
                        .getNavigationHandler()
                        .handleNavigation(FacesContext.getCurrentInstance(),
                        "null", "/" + navigationPage + "?faces-redirect=true");
    }*/

    /* when select child tree node ( has navigation page ) open its navigation page 
       when select parent tree node ( has no navigation page ) select the parent node but still open the current navigation page
     */
    /*private void OpenNavigationPage(TreeNode treeNode,boolean isChangeLanguage)  {
        ApplicationTree appTree;
        if(treeNode != null){            
            appTree = applicationTreeService.findApplicationTreeByID( ((Document) treeNode.getData()).getId());
            currentNavigationPage = appTree.getNavigationPage();
        if (null != currentNavigationPage && currentNavigationPage.contains(".xhtml")) {
            String urlPrefix_1 = "/secured";
            if(!isChangeLanguage)
                expandSelectedNodeOnly(treeNode);
            try {                
                if(currentNavigationPage != null && (currentNavigationPage.contains("next.xhtml") ||
                                                     currentNavigationPage.contains("underConstruction.xhtml")))
                    urlPrefix_1 = "";
                    
                FacesContext
                        .getCurrentInstance()
                        .getApplication()
                        .getNavigationHandler()
                        .handleNavigation(FacesContext.getCurrentInstance(),
                        "null", urlPrefix_1 + "/" + currentNavigationPage + "?faces-redirect=true");
                treeNode.setExpanded(true);
            } catch (Exception e) {
            	logger.error(e);
                // TODO: handle exception
            }
            oldNavigationPage = currentNavigationPage;
        } else { //Commented to replace it with expand folder node when select         	
            if (isSearchByButtons) {
                String urlPrefix_2 = "/secured";
                if ((currentNavigationPage == null && (oldNavigationPage.contains("next.xhtml")
                        || oldNavigationPage.contains("underConstruction.xhtml")
                        || oldNavigationPage.contains("mainPage.xhtml")))
                        || currentNavigationPage != null && (currentNavigationPage.contains("next.xhtml")
                        || currentNavigationPage.contains("underConstruction.xhtml")
                        || currentNavigationPage.contains("mainPage.xhtml")))
                    urlPrefix_2 = "";
                FacesContext
                        .getCurrentInstance()
                        .getApplication()
                        .getNavigationHandler()
                        .handleNavigation(FacesContext.getCurrentInstance(),
                        "null", urlPrefix_2 + "/" + ((currentNavigationPage == null) ? oldNavigationPage : currentNavigationPage) + "?faces-redirect=true");
            }
        }
        oldSelectedNode = treeNode;
        }
    }*/
    
  //TODO Select Navigation Tree Node When Open Page From URL 
    private void OpenNavigationPage(TreeNode treeNode,boolean isChangeLanguage)  {
        ApplicationTree appTree;
        if(treeNode == null){
        	appTree = applicationTreeService.findApplicationTreeByXHTMLName(currentNavigationPage);
        	if(appTree != null){
        		allTreeNodes = new ArrayList<TreeNode>();
            	if(loadChildNodesOnly){
            		allTreeNodes = rootForChildOnly.getChildren();
            	}
            	else{
            		allTreeNodes = getAllChildren(rootForAllTree);
            	} 
            	for(TreeNode tNode : allTreeNodes){
            		if(((Document) tNode.getData()).getId().compareTo(appTree.getId()) == 0){
            			treeNode = tNode;
            			break;
            		}
            			
            	}
        	}        	
        }
        else
        	appTree = applicationTreeService.findApplicationTreeByID( ((Document) treeNode.getData()).getId());    	
        
        if(appTree != null){                        
            currentNavigationPage = appTree.getNavigationPage();
        if (null != currentNavigationPage && currentNavigationPage.contains(".xhtml")) {
            String urlPrefix_1 = "/secured";
            if(!isChangeLanguage && treeNode != null)
                expandSelectedNodeOnly(treeNode);
            try {                
                if(currentNavigationPage != null && (currentNavigationPage.contains("next.xhtml") ||
                                                     currentNavigationPage.contains("underConstruction.xhtml")))
                    urlPrefix_1 = "";
                    
                FacesContext
                        .getCurrentInstance()
                        .getApplication()
                        .getNavigationHandler()
                        .handleNavigation(FacesContext.getCurrentInstance(),
                        "null", urlPrefix_1 + "/" + currentNavigationPage + "?faces-redirect=true");
                if(treeNode != null)
                	treeNode.setExpanded(true);
            } catch (Exception e) {
            	logger.error(e);
            }
            oldNavigationPage = currentNavigationPage;
        }
        oldSelectedNode = treeNode;
        }
    }
    
        public void changeTreeLanguage(String currentLanguage)  {
        this.currentLanguage = currentLanguage;
        OpenNavigationPage(oldSelectedNode,true);
        //TODO Select Navigation Tree Node When Open Page From URL
        /*OpenNavigationPage(oldSelectedNode,false);*/
    }

    /**
     * @return the loadChildNodesOnly
     */
    public boolean isLoadChildNodesOnly() {
        return loadChildNodesOnly;
    }

    /**
     * @param loadChildNodesOnly the loadChildNodesOnly to set
     */
    public void setLoadChildNodesOnly(boolean loadChildNodesOnly) {
        this.loadChildNodesOnly = loadChildNodesOnly;
    }

    /**
     * @return the searchWord
     */
    public String getNodeFilter() {
        return searchWord;
    }

    /**
     * @param searchWord the searchWord to set
     */
    public void setNodeFilter(String searchWord) {
        this.searchWord = searchWord;
    }

    /**
     * @return the enableSearchButt
     */
    public boolean isEnableSearchButt() {
        return enableSearchButt;
    }

    /**
     * @param enableSearchButt the enableSearchButt to set
     */
    public void setEnableSearchButt(boolean enableSearchButt) {
        this.enableSearchButt = enableSearchButt;
    }
    
    public List<ApplicationTree> getFooterATreeChildPages() {
        return footerATreeChildPages;
    }
    
    public void setFooterATreeChildPages(List<ApplicationTree> footerATreeChildPages) {
        this.footerATreeChildPages = footerATreeChildPages;
    }        

    /*private UserBean getCurrentUserAccess() {
        FacesContext context = FacesContext.getCurrentInstance();
        ELContext elContext = context.getELContext();
        Application application = context.getApplication();
        ExpressionFactory expressionFactory = application.getExpressionFactory();
        ValueExpression ve = expressionFactory.createValueExpression(elContext, "#{user}", UserBean.class);
        return ((UserBean) ve.getValue(elContext));
    }*/
    
    private User getCurrentUser() {
    	FacesContext context = FacesContext.getCurrentInstance();
    	UserBean userBean = (UserBean) context.getApplication().evaluateExpressionGet(context, "#{user}", UserBean.class);
    	return userBean != null ? userBean.getCurrentUser() : null;
    }

	public ApplicationTreeService getApplicationTreeService() {
		return applicationTreeService;
	}

	public void setApplicationTreeService(
			ApplicationTreeService applicationTreeService) {
		this.applicationTreeService = applicationTreeService;
	}

	public List<ApplicationTree> getChildOnlyNavigationNodes() {
		return childOnlyNavigationNodes;
	}

	public void setChildOnlyNavigationNodes(
			List<ApplicationTree> childOnlyNavigationNodes) {
		this.childOnlyNavigationNodes = childOnlyNavigationNodes;
	}

	public List<String> getUserAuthorizedNavigationPages() {
		return userAuthorizedNavigationPages;
	}

	public void setUserAuthorizedNavigationPages(
			List<String> userAuthorizedNavigationPages) {
		this.userAuthorizedNavigationPages = userAuthorizedNavigationPages;
	}

	//TODO Select Navigation Tree Node When Open Page From URL
	public void setCurrentNavigationPage(String currentNavigationPage) {
		this.currentNavigationPage = currentNavigationPage;
	}
}
